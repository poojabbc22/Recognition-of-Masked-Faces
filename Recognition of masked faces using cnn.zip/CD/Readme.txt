STEPS:
Download and install the Anaconda in the system.

Step 1: Open the jupyter notebook and upload the FaceSeamlessnetry.ipynb file under a new project folder.
Step 2: Open the file and restart the Kernel in the jupyter notebook.
Step 3: Open the source code directory in the visual studio software.
Step 4: Run the FaceSeamlessnetry.ipynb file. It will capture the face and stores it in the Images folder.
Step 5: Open the Images folder, cut all the images. 
Step 6: Then open the Dataset folder and Create a directory in both train and test folder name the directory which should be the person name whom face had been captured.
Step 7: Paste all images in the train->"new folder" and half of the images in the test->"new folder".
Step 8: Open anaconda prompt and locate your source code directory.
Step 9: Give the command 'python cnn.py' and press enter.
Step 10: Then give another command 'python main.py' and press enter.
Step 11: Real time camera will be accessible and shows the result as recognition of masked faces.